#include <ros/ros.h>
#include <hector_costmap/hector_costmap.h>

int main (int argc, char** argv)
{
    ros::init(argc,argv,"hector_costmap");

    CostMapCalculation costMapCalc;

    return (-1);
}
